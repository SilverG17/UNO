using System;
using System.Collections.Generic;
using System.Net.Sockets;
using UnityEngine; // dùng JsonUtility

public class ServerMessageHandler
{
    private RoomManager roomManager;

    private Dictionary<TcpClient, string> clientPlayers;
    private Dictionary<string, TcpClient> playerToClient;
    private Dictionary<TcpClient, string> clientRooms;

    private Action<TcpClient, string> sendToClient;
    private Action<string, string> sendToRoom;

    public ServerMessageHandler(
        RoomManager roomManager,
        Dictionary<TcpClient, string> clientPlayers,
        Dictionary<string, TcpClient> playerToClient,
        Dictionary<TcpClient, string> clientRooms,
        Action<TcpClient, string> sendToClient,
        Action<string, string> sendToRoom)
    {
        this.roomManager = roomManager;
        this.clientPlayers = clientPlayers;
        this.playerToClient = playerToClient;
        this.clientRooms = clientRooms;
        this.sendToClient = sendToClient;
        this.sendToRoom = sendToRoom;
    }

    public void HandleMessage(TcpClient client, string json)
    {
        var wrapper = Protocol.ParseWrapper(json);

        switch (wrapper.type)
        {
            case Protocol.PLAY_CARD:
                HandlePlayCard(client, wrapper.payload);
                break;

            case Protocol.DRAW_CARD:
                HandleDrawCard(client, wrapper.payload);
                break;

            case Protocol.CALL_UNO:
                HandleCallUno(client, wrapper.payload);
                break;
        }
    }

    private void HandlePlayCard(TcpClient client, string payload)
    {
        var msg = Protocol.FromJson<PlayCardMsg>(payload);

        if (!clientPlayers.TryGetValue(client, out var playerId))
            return;

        if (!clientRooms.TryGetValue(client, out var roomId))
            return;

        var room = roomManager.GetRoom(roomId);
        if (room == null) return;

        bool success = room.GameManager.PlayCard(playerId, msg.card);

        if (!success)
        {
            sendToClient(client, Protocol.CreateMessage(
                Protocol.ERROR,
                new { message = "Invalid move" }
            ));
            return;
        }

        // broadcast state
        sendToRoom(roomId, Protocol.CreateMessage(
            Protocol.GAME_STATE,
            room.GameManager.GetState()
        ));
    }

    private void HandleDrawCard(TcpClient client, string payload)
    {
        var msg = Protocol.FromJson<DrawCardMsg>(payload);

        if (!clientPlayers.TryGetValue(client, out var playerId)) return;
        if (!clientRooms.TryGetValue(client, out var roomId)) return;

        var room = roomManager.GetRoom(roomId);
        if (room == null) return;

        room.GameManager.DrawCard(playerId);

        sendToRoom(roomId, Protocol.CreateMessage(
            Protocol.GAME_STATE,
            room.GameManager.GetState()
        ));
    }

    private void HandleCallUno(TcpClient client, string payload)
    {
        var msg = Protocol.FromJson<CallUnoMsg>(payload);

        if (!clientPlayers.TryGetValue(client, out var playerId)) return;
        if (!clientRooms.TryGetValue(client, out var roomId)) return;

        var room = roomManager.GetRoom(roomId);
        if (room == null) return;

        room.GameManager.CallUno(playerId);

        sendToRoom(roomId, Protocol.CreateMessage(
            Protocol.GAME_STATE,
            room.GameManager.GetState()
        ));
    }
}
